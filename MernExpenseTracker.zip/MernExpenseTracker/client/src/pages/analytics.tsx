import { DashboardLayout } from '@/components/DashboardLayout';
import { Card } from '@/components/ui/card';
import { TrendingUp } from 'lucide-react';

export default function Analytics() {
  return (
    <DashboardLayout>
      <div className="p-6 lg:p-8 max-w-7xl mx-auto">
        <div className="mb-6">
          <h2 className="text-2xl font-semibold mb-1">Analytics</h2>
          <p className="text-muted-foreground">
            Gain insights into your spending patterns
          </p>
        </div>

        <div className="flex flex-col items-center justify-center py-16 text-center">
          <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-4">
            <TrendingUp className="w-8 h-8 text-primary" />
          </div>
          <h3 className="text-xl font-semibold mb-2">Analytics Coming Soon</h3>
          <p className="text-muted-foreground mb-6 max-w-md">
            We're working on bringing you detailed analytics and insights about your spending habits.
          </p>
        </div>
      </div>
    </DashboardLayout>
  );
}
