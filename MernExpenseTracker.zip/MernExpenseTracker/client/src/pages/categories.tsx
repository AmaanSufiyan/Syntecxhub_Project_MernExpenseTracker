import { useQuery } from '@tanstack/react-query';
import { DashboardLayout } from '@/components/DashboardLayout';
import { Card } from '@/components/ui/card';
import { CategoryIcon, getCategoryColor } from '@/components/CategoryIcon';
import { useAuth } from '@/lib/auth';
import { categories, type Category } from '@shared/schema';
import type { Expense } from '@shared/schema';
import { Loader2, Inbox } from 'lucide-react';

export default function Categories() {
  const { token } = useAuth();

  const { data: expenses = [], isLoading } = useQuery<Expense[]>({
    queryKey: ['/api/expenses'],
    enabled: !!token,
  });

  const categoryStats = categories.map(category => {
    const categoryExpenses = expenses.filter(e => e.category === category);
    const total = categoryExpenses.reduce((sum, e) => sum + parseFloat(e.amount), 0);
    const count = categoryExpenses.length;
    return { category, total, count };
  }).sort((a, b) => b.total - a.total);

  return (
    <DashboardLayout>
      <div className="p-6 lg:p-8 max-w-7xl mx-auto">
        <div className="mb-6">
          <h2 className="text-2xl font-semibold mb-1">Categories</h2>
          <p className="text-muted-foreground">
            View your spending breakdown by category
          </p>
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center py-16" data-testid="loading-categories">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : expenses.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center" data-testid="empty-state">
            <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-4">
              <Inbox className="w-8 h-8 text-primary" />
            </div>
            <h3 className="text-xl font-semibold mb-2">No expenses yet</h3>
            <p className="text-muted-foreground mb-6 max-w-md">
              Add some expenses to see your category breakdown
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {categoryStats.map(({ category, total, count }) => (
              <Card 
                key={category} 
                className="p-6 hover:shadow-md transition-shadow"
                data-testid={`card-category-${category.toLowerCase()}`}
              >
                <div className={`w-12 h-12 rounded-lg ${getCategoryColor(category as Category)} flex items-center justify-center mb-4`}>
                  <CategoryIcon category={category as Category} className="w-6 h-6" />
                </div>
                
                <h3 className="font-semibold mb-2">{category}</h3>
                
                <p className="text-2xl font-bold font-mono mb-1" data-testid={`text-category-${category.toLowerCase()}-total`}>
                  ${total.toFixed(2)}
                </p>
                
                <p className="text-sm text-muted-foreground">
                  {count} {count === 1 ? 'transaction' : 'transactions'}
                </p>
              </Card>
            ))}
          </div>
        )}
      </div>
    </DashboardLayout>
  );
}
