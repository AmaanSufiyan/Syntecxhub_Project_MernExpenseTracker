import { Card } from '@/components/ui/card';
import { DollarSign, Receipt, TrendingUp, Calendar } from 'lucide-react';
import type { Expense } from '@shared/schema';

interface StatisticsCardsProps {
  expenses: Expense[];
}

export function StatisticsCards({ expenses }: StatisticsCardsProps) {
  const totalExpenses = expenses.reduce(
    (sum, expense) => sum + parseFloat(expense.amount),
    0
  );

  const thisMonth = new Date().getMonth();
  const thisYear = new Date().getFullYear();
  const monthlyExpenses = expenses.filter(expense => {
    const expenseDate = new Date(expense.date);
    return expenseDate.getMonth() === thisMonth && expenseDate.getFullYear() === thisYear;
  });

  const monthlyTotal = monthlyExpenses.reduce(
    (sum, expense) => sum + parseFloat(expense.amount),
    0
  );

  const lastMonth = new Date();
  lastMonth.setMonth(lastMonth.getMonth() - 1);
  const lastMonthExpenses = expenses.filter(expense => {
    const expenseDate = new Date(expense.date);
    return expenseDate.getMonth() === lastMonth.getMonth() && 
           expenseDate.getFullYear() === lastMonth.getFullYear();
  });

  const lastMonthTotal = lastMonthExpenses.reduce(
    (sum, expense) => sum + parseFloat(expense.amount),
    0
  );

  const monthChange = lastMonthTotal > 0 
    ? ((monthlyTotal - lastMonthTotal) / lastMonthTotal * 100) 
    : 0;

  const categoryTotals = expenses.reduce((acc, expense) => {
    acc[expense.category] = (acc[expense.category] || 0) + parseFloat(expense.amount);
    return acc;
  }, {} as Record<string, number>);

  const topCategory = Object.entries(categoryTotals).sort((a, b) => b[1] - a[1])[0];

  const stats = [
    {
      label: 'Total Expenses',
      value: `$${totalExpenses.toFixed(2)}`,
      change: null,
      icon: DollarSign,
      bgColor: 'bg-primary/10',
      iconColor: 'text-primary',
    },
    {
      label: 'This Month',
      value: `$${monthlyTotal.toFixed(2)}`,
      change: monthChange !== 0 ? `${monthChange > 0 ? '+' : ''}${monthChange.toFixed(1)}%` : null,
      isNegative: monthChange > 0,
      icon: Calendar,
      bgColor: 'bg-chart-2/10',
      iconColor: 'text-chart-2',
    },
    {
      label: 'Transactions',
      value: expenses.length.toString(),
      change: null,
      icon: Receipt,
      bgColor: 'bg-chart-3/10',
      iconColor: 'text-chart-3',
    },
    {
      label: 'Top Category',
      value: topCategory ? `$${topCategory[1].toFixed(2)}` : '$0.00',
      subtitle: topCategory ? topCategory[0] : 'None',
      icon: TrendingUp,
      bgColor: 'bg-chart-4/10',
      iconColor: 'text-chart-4',
    },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
      {stats.map((stat, index) => {
        const Icon = stat.icon;
        return (
          <Card 
            key={index} 
            className="p-6 hover:shadow-md transition-shadow"
            data-testid={`card-stat-${stat.label.toLowerCase().replace(' ', '-')}`}
          >
            <div className="flex items-start justify-between mb-4">
              <div className={`w-12 h-12 rounded-lg ${stat.bgColor} flex items-center justify-center`}>
                <Icon className={`w-6 h-6 ${stat.iconColor}`} />
              </div>
            </div>
            
            <p className="text-sm text-muted-foreground font-medium mb-1">
              {stat.label}
            </p>
            
            <div className="flex items-baseline gap-2">
              <p className="text-3xl font-bold font-mono" data-testid={`text-${stat.label.toLowerCase().replace(' ', '-')}-value`}>
                {stat.value}
              </p>
              {stat.change && (
                <span className={`text-sm font-medium ${stat.isNegative ? 'text-destructive' : 'text-chart-2'}`}>
                  {stat.change}
                </span>
              )}
            </div>
            
            {stat.subtitle && (
              <p className="text-sm text-muted-foreground mt-1">
                {stat.subtitle}
              </p>
            )}
          </Card>
        );
      })}
    </div>
  );
}
