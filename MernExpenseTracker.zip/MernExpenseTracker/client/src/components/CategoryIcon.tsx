import { 
  Utensils, 
  Car, 
  ShoppingBag, 
  FileText, 
  Film, 
  Heart, 
  MoreHorizontal 
} from 'lucide-react';
import type { Category } from '@shared/schema';

const categoryConfig: Record<Category, { icon: typeof Utensils; color: string }> = {
  Food: { icon: Utensils, color: 'text-category-food' },
  Transport: { icon: Car, color: 'text-category-transport' },
  Shopping: { icon: ShoppingBag, color: 'text-category-shopping' },
  Bills: { icon: FileText, color: 'text-category-bills' },
  Entertainment: { icon: Film, color: 'text-category-entertainment' },
  Healthcare: { icon: Heart, color: 'text-category-healthcare' },
  Other: { icon: MoreHorizontal, color: 'text-category-other' },
};

export function CategoryIcon({ 
  category, 
  className = "w-6 h-6" 
}: { 
  category: Category; 
  className?: string;
}) {
  const config = categoryConfig[category];
  const Icon = config.icon;
  
  return <Icon className={`${className} ${config.color}`} />;
}

export function getCategoryColor(category: Category): string {
  const colors: Record<Category, string> = {
    Food: 'bg-category-food/10 border-category-food/20',
    Transport: 'bg-category-transport/10 border-category-transport/20',
    Shopping: 'bg-category-shopping/10 border-category-shopping/20',
    Bills: 'bg-category-bills/10 border-category-bills/20',
    Entertainment: 'bg-category-entertainment/10 border-category-entertainment/20',
    Healthcare: 'bg-category-healthcare/10 border-category-healthcare/20',
    Other: 'bg-category-other/10 border-category-other/20',
  };
  return colors[category];
}
