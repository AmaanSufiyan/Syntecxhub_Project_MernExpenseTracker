import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { CategoryIcon, getCategoryColor } from './CategoryIcon';
import { Edit2, Trash2 } from 'lucide-react';
import type { Expense } from '@shared/schema';
import { format } from 'date-fns';

interface ExpenseCardProps {
  expense: Expense;
  onEdit: (expense: Expense) => void;
  onDelete: (id: string) => void;
}

export function ExpenseCard({ expense, onEdit, onDelete }: ExpenseCardProps) {
  const formattedDate = format(new Date(expense.date), 'MMM dd, yyyy');
  
  return (
    <Card 
      className="p-4 hover:shadow-md transition-all cursor-pointer group relative"
      data-testid={`card-expense-${expense.id}`}
    >
      <div className="flex items-start justify-between mb-3">
        <div className={`w-10 h-10 rounded-lg ${getCategoryColor(expense.category as any)} flex items-center justify-center`}>
          <CategoryIcon category={expense.category as any} className="w-5 h-5" />
        </div>
        <p className="text-2xl font-bold font-mono" data-testid={`text-amount-${expense.id}`}>
          ${parseFloat(expense.amount).toFixed(2)}
        </p>
      </div>

      <h3 className="font-medium mb-2 text-base" data-testid={`text-description-${expense.id}`}>
        {expense.description}
      </h3>

      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground" data-testid={`text-date-${expense.id}`}>
          {formattedDate}
        </p>
        <Badge variant="secondary" className="text-xs" data-testid={`badge-category-${expense.id}`}>
          {expense.category}
        </Badge>
      </div>

      <div className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity flex gap-1">
        <Button
          size="icon"
          variant="ghost"
          className="h-8 w-8"
          onClick={(e) => {
            e.stopPropagation();
            onEdit(expense);
          }}
          data-testid={`button-edit-${expense.id}`}
        >
          <Edit2 className="w-4 h-4" />
        </Button>
        <Button
          size="icon"
          variant="ghost"
          className="h-8 w-8 text-destructive hover:text-destructive"
          onClick={(e) => {
            e.stopPropagation();
            onDelete(expense.id);
          }}
          data-testid={`button-delete-${expense.id}`}
        >
          <Trash2 className="w-4 h-4" />
        </Button>
      </div>
    </Card>
  );
}
