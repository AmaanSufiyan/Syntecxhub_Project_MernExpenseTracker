import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { insertExpenseSchema, type InsertExpense, categories, type Category } from '@shared/schema';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { CategoryIcon, getCategoryColor } from './CategoryIcon';
import type { Expense } from '@shared/schema';

interface AddExpenseModalProps {
  open: boolean;
  onClose: () => void;
  onSubmit: (data: InsertExpense) => Promise<void>;
  editingExpense?: Expense | null;
}

export function AddExpenseModal({ open, onClose, onSubmit, editingExpense }: AddExpenseModalProps) {
  const form = useForm<InsertExpense>({
    resolver: zodResolver(insertExpenseSchema),
    defaultValues: editingExpense ? {
      amount: editingExpense.amount,
      description: editingExpense.description,
      category: editingExpense.category as Category,
      date: new Date(editingExpense.date).toISOString().split('T')[0],
    } : {
      amount: '',
      description: '',
      category: undefined,
      date: new Date().toISOString().split('T')[0],
    },
  });

  const handleSubmit = async (data: InsertExpense) => {
    await onSubmit(data);
    form.reset();
    onClose();
  };

  const handleClose = () => {
    form.reset();
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle className="text-2xl">
            {editingExpense ? 'Edit Expense' : 'Add New Expense'}
          </DialogTitle>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="amount"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Amount</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <span className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground font-mono text-xl">
                        $
                      </span>
                      <Input
                        {...field}
                        type="text"
                        placeholder="0.00"
                        className="h-14 pl-8 text-2xl font-mono"
                        data-testid="input-amount"
                      />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      placeholder="What did you spend on?"
                      className="h-12"
                      data-testid="input-description"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="category"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Category</FormLabel>
                  <FormControl>
                    <div className="grid grid-cols-3 gap-3">
                      {categories.map((category) => {
                        const isSelected = field.value === category;
                        return (
                          <button
                            key={category}
                            type="button"
                            onClick={() => field.onChange(category)}
                            className={`
                              p-4 rounded-lg border-2 transition-all
                              ${isSelected 
                                ? 'border-primary bg-primary/5' 
                                : 'border-border hover:border-primary/50'
                              }
                            `}
                            data-testid={`category-${category.toLowerCase()}`}
                          >
                            <div className={`w-8 h-8 rounded-lg ${getCategoryColor(category)} mx-auto mb-2 flex items-center justify-center`}>
                              <CategoryIcon category={category} className="w-5 h-5" />
                            </div>
                            <p className="text-sm font-medium text-center">
                              {category}
                            </p>
                          </button>
                        );
                      })}
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="date"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Date</FormLabel>
                  <FormControl>
                    <Input
                      {...field}
                      type="date"
                      className="h-12"
                      data-testid="input-date"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <DialogFooter className="gap-2">
              <Button
                type="button"
                variant="outline"
                onClick={handleClose}
                data-testid="button-cancel"
              >
                Cancel
              </Button>
              <Button type="submit" data-testid="button-save-expense">
                {editingExpense ? 'Update Expense' : 'Add Expense'}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
