import { useAuth } from '@/lib/auth';
import { Redirect } from 'wouter';
import type { ComponentType } from 'react';

export function PrivateRoute({ component: Component }: { component: ComponentType }) {
  const { isAuthenticated } = useAuth();

  if (!isAuthenticated) {
    return <Redirect to="/login" />;
  }

  return <Component />;
}
