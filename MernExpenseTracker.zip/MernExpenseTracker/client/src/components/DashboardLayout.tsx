import { useAuth } from '@/lib/auth';
import { useLocation } from 'wouter';
import { 
  LayoutDashboard, 
  List, 
  Tags, 
  BarChart3, 
  LogOut,
  DollarSign,
  Plus
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import type { ReactNode } from 'react';

interface NavItem {
  icon: typeof LayoutDashboard;
  label: string;
  path: string;
}

const navItems: NavItem[] = [
  { icon: LayoutDashboard, label: 'Dashboard', path: '/' },
  { icon: List, label: 'All Expenses', path: '/expenses' },
  { icon: Tags, label: 'Categories', path: '/categories' },
  { icon: BarChart3, label: 'Analytics', path: '/analytics' },
];

export function DashboardLayout({ children, onAddExpense }: { children: ReactNode; onAddExpense?: () => void }) {
  const { user, logout } = useAuth();
  const [location, setLocation] = useLocation();

  const handleLogout = () => {
    logout();
    setLocation('/login');
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <div className="min-h-screen bg-background flex">
      <aside className="w-64 border-r bg-card flex flex-col">
        <div className="p-6 border-b">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-primary flex items-center justify-center">
              <DollarSign className="w-6 h-6 text-primary-foreground" />
            </div>
            <span className="text-xl font-bold">ExpenseTracker</span>
          </div>
        </div>

        <nav className="flex-1 p-4 space-y-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location === item.path;
            
            return (
              <button
                key={item.path}
                onClick={() => setLocation(item.path)}
                className={`
                  w-full flex items-center gap-3 px-4 h-10 rounded-lg transition-colors
                  ${isActive 
                    ? 'bg-primary/10 text-primary font-medium' 
                    : 'text-foreground hover-elevate'
                  }
                `}
                data-testid={`nav-${item.label.toLowerCase().replace(' ', '-')}`}
              >
                <Icon className="w-5 h-5" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t">
          <div className="flex items-center gap-3 mb-4">
            <Avatar className="w-10 h-10">
              <AvatarFallback className="bg-primary/10 text-primary font-semibold">
                {user && getInitials(user.name)}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <p className="font-medium truncate">{user?.name}</p>
              <p className="text-sm text-muted-foreground truncate">{user?.email}</p>
            </div>
          </div>
          <Button
            variant="outline"
            className="w-full"
            onClick={handleLogout}
            data-testid="button-logout"
          >
            <LogOut className="w-4 h-4 mr-2" />
            Logout
          </Button>
        </div>
      </aside>

      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="h-16 border-b bg-card px-6 flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold">
              {navItems.find(item => item.path === location)?.label || 'Dashboard'}
            </h1>
          </div>
          
          {onAddExpense && (
            <Button
              onClick={onAddExpense}
              className="gap-2"
              data-testid="button-add-expense"
            >
              <Plus className="w-4 h-4" />
              Add Expense
            </Button>
          )}
        </header>

        <main className="flex-1 overflow-auto">
          {children}
        </main>
      </div>

      {onAddExpense && (
        <button
          onClick={onAddExpense}
          className="lg:hidden fixed bottom-6 right-6 w-14 h-14 rounded-full bg-primary text-primary-foreground shadow-lg flex items-center justify-center hover-elevate active-elevate-2"
          data-testid="button-add-expense-mobile"
        >
          <Plus className="w-6 h-6" />
        </button>
      )}
    </div>
  );
}
