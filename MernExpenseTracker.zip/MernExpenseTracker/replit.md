# Expense Tracker Application

## Overview

This is a full-stack expense tracking application built with React, Express, and PostgreSQL. The application allows users to securely manage their personal expenses by creating accounts, logging expenses with categories, and viewing spending analytics. The system features JWT-based authentication, a modern UI built with shadcn/ui components, and a clean REST API architecture.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Build System**
- **React 18** with TypeScript for the UI layer
- **Vite** as the build tool and development server
- **Wouter** for client-side routing (lightweight alternative to React Router)
- **TanStack Query (React Query)** for server state management and API caching

**UI Design System**
- **shadcn/ui** component library based on Radix UI primitives
- **Tailwind CSS** for styling with a custom design system
- **Design Philosophy**: Hybrid approach combining Material Design principles with modern fintech application aesthetics (inspired by Mint, Stripe Dashboard, Linear)
- **Typography**: Inter font for UI elements, JetBrains Mono for numerical/currency data
- **Color System**: Custom HSL-based theming with support for light/dark modes

**State Management**
- React Context API for authentication state (`AuthProvider`)
- TanStack Query for server state (expenses, user data)
- React Hook Form with Zod validation for form state

**Key Frontend Patterns**
- Protected routes using `PrivateRoute` wrapper component
- Public routes that redirect authenticated users away from auth pages
- Centralized API request handling via `apiRequest` utility
- JWT token stored in localStorage and sent via Authorization header

### Backend Architecture

**Server Framework**
- **Express.js** with TypeScript running on Node.js
- **ESM modules** (type: "module" in package.json)
- Custom Vite integration for development with HMR support

**API Design**
- RESTful API endpoints under `/api` prefix
- JWT-based authentication middleware
- Request/response logging middleware for API routes
- JSON body parsing with raw body capture for webhook support

**Authentication System**
- **JWT tokens** for session management (7-day expiration)
- **bcrypt** for password hashing (10 salt rounds)
- Token generation and validation via custom middleware (`authenticateToken`)
- Environment variable `SESSION_SECRET` or `JWT_SECRET` required for token signing

**Storage Layer**
- Abstract `IStorage` interface defining data operations
- `MemStorage` implementation for in-memory storage (development/testing)
- Designed to support PostgreSQL via Drizzle ORM (schema defined, migration ready)

### Data Storage

**Database Solution**
- **PostgreSQL** as the target production database
- **Neon Serverless** driver for PostgreSQL connectivity
- **Drizzle ORM** for type-safe database operations and migrations
- Migration files output to `./migrations` directory

**Schema Design**

*Users Table*
- `id`: UUID primary key (generated via `gen_random_uuid()`)
- `name`: Text, required
- `email`: Text, required, unique
- `password`: Text, hashed with bcrypt

*Expenses Table*
- `id`: UUID primary key
- `userId`: Foreign key to users (not enforced at DB level in current schema)
- `amount`: Numeric(10,2) for currency precision
- `description`: Text, required
- `category`: Text enum (Food, Transport, Shopping, Bills, Entertainment, Healthcare, Other)
- `date`: Timestamp with timezone
- `createdAt`: Timestamp with timezone, auto-populated

**Validation**
- Zod schemas for runtime validation (`insertUserSchema`, `insertExpenseSchema`, `loginSchema`)
- Client and server-side validation using shared schema definitions
- Email format validation, password length requirements (6+ characters)

### External Dependencies

**Core Framework Dependencies**
- Express.js for HTTP server
- React 18 for UI framework
- Vite for build tooling and development

**Database & ORM**
- @neondatabase/serverless - Neon PostgreSQL driver
- drizzle-orm - Type-safe ORM
- drizzle-kit - Migration management

**Authentication & Security**
- jsonwebtoken - JWT token generation/verification
- bcryptjs - Password hashing
- zod - Schema validation

**UI Component Library**
- @radix-ui/* - Headless UI primitives (20+ component packages)
- shadcn/ui configuration for component styling
- lucide-react - Icon library

**State Management & Data Fetching**
- @tanstack/react-query - Server state management
- react-hook-form - Form state management
- @hookform/resolvers - Zod integration for forms

**Styling**
- tailwindcss - Utility-first CSS framework
- tailwind-merge & clsx - Class name utilities
- class-variance-authority - Component variant management

**Development Tools**
- tsx - TypeScript execution for development
- esbuild - Production bundling
- @replit/vite-plugin-* - Replit-specific development enhancements

**Routing**
- wouter - Lightweight client-side routing