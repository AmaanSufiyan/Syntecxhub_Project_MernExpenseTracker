import { type User, type InsertUser, type Expense, type InsertExpense } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getExpensesByUserId(userId: string): Promise<Expense[]>;
  getExpense(id: string): Promise<Expense | undefined>;
  createExpense(userId: string, expense: InsertExpense): Promise<Expense>;
  updateExpense(id: string, userId: string, expense: Partial<InsertExpense>): Promise<Expense | undefined>;
  deleteExpense(id: string, userId: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private expenses: Map<string, Expense>;

  constructor() {
    this.users = new Map();
    this.expenses = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getExpensesByUserId(userId: string): Promise<Expense[]> {
    return Array.from(this.expenses.values()).filter(
      (expense) => expense.userId === userId
    );
  }

  async getExpense(id: string): Promise<Expense | undefined> {
    return this.expenses.get(id);
  }

  async createExpense(userId: string, insertExpense: InsertExpense): Promise<Expense> {
    const id = randomUUID();
    const now = new Date();
    const expense: Expense = {
      id,
      userId,
      amount: insertExpense.amount,
      description: insertExpense.description,
      category: insertExpense.category,
      date: new Date(insertExpense.date),
      createdAt: now,
    };
    this.expenses.set(id, expense);
    return expense;
  }

  async updateExpense(
    id: string,
    userId: string,
    updates: Partial<InsertExpense>
  ): Promise<Expense | undefined> {
    const expense = this.expenses.get(id);
    if (!expense || expense.userId !== userId) {
      return undefined;
    }

    const updatedExpense: Expense = {
      ...expense,
      ...(updates.amount && { amount: updates.amount }),
      ...(updates.description && { description: updates.description }),
      ...(updates.category && { category: updates.category }),
      ...(updates.date && { date: new Date(updates.date) }),
    };

    this.expenses.set(id, updatedExpense);
    return updatedExpense;
  }

  async deleteExpense(id: string, userId: string): Promise<boolean> {
    const expense = this.expenses.get(id);
    if (!expense || expense.userId !== userId) {
      return false;
    }
    return this.expenses.delete(id);
  }
}

export const storage = new MemStorage();
