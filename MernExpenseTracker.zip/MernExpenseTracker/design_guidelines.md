# Design Guidelines for MERN Expense Tracker

## Design Approach
**Selected Approach:** Hybrid - Material Design System foundation with inspiration from modern fintech applications (Mint, Stripe Dashboard, Linear)

**Rationale:** This is a utility-focused financial application where trust, clarity, and efficiency are paramount. Users need to quickly input expenses, view their financial data, and understand spending patterns at a glance.

**Core Design Principles:**
1. Trust & Security: Clean, professional aesthetic that inspires confidence in financial data handling
2. Clarity First: Information hierarchy that makes data instantly scannable
3. Efficiency: Minimal clicks to complete core tasks (add expense, view balance)
4. Data Transparency: Clear visual feedback for all financial operations

---

## Typography System

**Font Families:**
- Primary: Inter (via Google Fonts) - headings, UI elements, data displays
- Monospace: JetBrains Mono - currency amounts, numerical data

**Type Scale:**
- Page Titles: text-4xl font-bold (authentication pages, main dashboard header)
- Section Headers: text-2xl font-semibold (dashboard sections like "Recent Transactions")
- Card Titles: text-lg font-medium (expense cards, category headers)
- Body Text: text-base font-normal (form labels, descriptions)
- Data/Numbers: text-xl font-semibold font-mono (expense amounts, totals)
- Helper Text: text-sm text-gray-600 (form hints, timestamps)
- Metadata: text-xs text-gray-500 (dates, category tags)

---

## Layout System

**Spacing Primitives:** Use Tailwind units of 2, 4, 6, 8, 12, 16, 20, 24
- Micro spacing (within components): p-2, gap-2
- Standard spacing (between related elements): p-4, gap-4, m-4
- Section spacing (between distinct groups): p-6, py-8, gap-6
- Major divisions (page sections): p-8, py-12, gap-8
- Large whitespace (page margins): p-12, py-16

**Grid System:**
- Authentication pages: Single column, max-w-md centered
- Dashboard: Two-column layout on desktop (sidebar + main content)
  - Sidebar: w-64 fixed
  - Main content area: flex-1 with max-w-7xl container
- Expense grid: grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4
- Statistics cards: grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4

**Container Strategy:**
- Form containers: max-w-md for focused input
- Content areas: max-w-6xl for optimal reading and data display
- Full-width dashboard sections with inner constraints

---

## Component Library

### Authentication Pages (Login/Signup)

**Layout Pattern:**
- Split-screen on desktop: Left side (40%) with branded content/illustration, Right side (60%) with form
- Mobile: Stacked, form-first
- Form container: Centered card with shadow-lg, rounded-xl, p-8
- Background: Subtle gradient or pattern for visual interest

**Form Elements:**
- Input fields: Full-width, h-12, px-4, rounded-lg border border-gray-300
- Focus states: ring-2 ring-blue-500 border-blue-500
- Labels: text-sm font-medium mb-2 block
- Submit button: w-full h-12 rounded-lg font-semibold
- Social login buttons (if applicable): Outlined style, h-12
- Link to alternate action (Login↔Signup): text-sm font-medium with underline on hover

**Validation:**
- Error messages: text-sm text-red-600 mt-1, icon prefix
- Success states: text-green-600 with checkmark icon
- Inline validation as user types for critical fields

### Dashboard Header

**Components:**
- App logo/name: Left-aligned, text-xl font-bold
- User profile dropdown: Right-aligned, avatar with name
- Navigation tabs or breadcrumbs below header
- Add Expense button: Prominent, fixed position or in header (rounded-full with + icon)
- Height: h-16 with shadow-sm

### Sidebar Navigation

**Structure:**
- Dashboard (home icon)
- All Expenses (list icon)
- Categories (tag icon)
- Analytics (chart icon)
- Settings (gear icon)

**Styling:**
- Items: h-10 px-4 rounded-lg with hover:bg-gray-100 transition
- Active state: bg-blue-50 text-blue-600 font-medium with left border accent
- Icon size: w-5 h-5 with consistent spacing (mr-3)

### Statistics Cards

**Grid Display:** 4 cards on desktop, 2 on tablet, 1 on mobile
**Card Structure:**
- Container: p-6 rounded-xl border border-gray-200
- Icon area: Top-left, w-12 h-12 rounded-lg bg-opacity-10 with category color
- Label: text-sm text-gray-600 font-medium
- Value: text-3xl font-bold font-mono mt-2
- Change indicator: text-sm with up/down arrow and percentage (green for positive context, red for negative)
- Subtle shadow on hover: hover:shadow-md transition

**Metrics to Display:**
- Total Balance/Budget Remaining
- Total Expenses This Month
- Number of Transactions
- Largest Category Spend

### Expense List/Feed

**Card Design:**
- Container: p-4 rounded-lg border border-gray-200 hover:shadow-md transition cursor-pointer
- Top row: Category icon (left) | Amount (right, large, font-mono)
- Middle row: Description text-base font-medium
- Bottom row: Date (text-sm text-gray-500) | Category badge
- Action buttons (edit/delete): Appear on hover, top-right corner

**List View Alternative:**
- Table with columns: Date | Description | Category | Amount | Actions
- Striped rows for readability
- Sticky header on scroll
- Mobile: Card view only

### Add/Edit Expense Modal or Page

**Form Layout:**
- Modal: max-w-2xl with backdrop blur
- Fields in logical groups:
  1. Amount input (large, prominent, currency symbol prefix)
  2. Description (text input)
  3. Category (dropdown or tag selector with icons)
  4. Date picker (default to today)
  5. Optional notes (textarea)
- Action buttons: Cancel (outline) | Save (solid, primary color)

**Category Selector:**
- Grid of category cards with icons: grid-cols-3 gap-3
- Each category: p-4 rounded-lg border-2 hover:border-blue-500 transition
- Selected state: border-blue-500 bg-blue-50
- Common categories: Food, Transport, Shopping, Bills, Entertainment, Healthcare, Other

### Analytics/Charts Section

**Chart Components:**
- Monthly trend line chart (last 6 months)
- Category breakdown pie/donut chart
- Top spending categories bar chart
- Container: p-6 rounded-xl border border-gray-200

**Chart Styling:**
- Clean, minimal axes
- Consistent color palette for categories
- Interactive tooltips on hover
- Legend with category totals

### Category Management

**Category Cards:**
- grid-cols-2 md:grid-cols-3 lg:grid-cols-4
- Each card: p-4 rounded-lg with category color as accent
- Icon + Label + Total spent
- Edit/Delete actions on hover

---

## Visual Specifications

### Color Palette Strategy
Colors will be defined later, but structure should support:
- Primary color for CTAs, active states, accents
- Category colors (8-10 distinct hues for expense categories)
- Neutral grays for UI framework
- Success/warning/error semantic colors
- Subtle backgrounds for cards and sections

### Iconography
**Library:** Heroicons (outline for navigation, solid for inline actions)
**Size Standards:**
- Navigation icons: w-5 h-5
- Category icons: w-6 h-6
- Large feature icons: w-12 h-12
- Button icons: w-4 h-4

**Category Icons (placeholders):**
- Food: utensils icon
- Transport: car/bus icon
- Shopping: shopping-bag icon
- Bills: document-text icon
- Entertainment: film icon
- Healthcare: heart icon

### Borders & Shadows
- Card borders: border border-gray-200
- Elevated cards: shadow-md
- Interactive hover: shadow-lg
- Modal backdrop: bg-black bg-opacity-50
- Dividers: border-t border-gray-200

### Border Radius
- Buttons: rounded-lg (0.5rem)
- Cards: rounded-xl (0.75rem)
- Inputs: rounded-lg
- Modal: rounded-2xl
- Pills/Badges: rounded-full

---

## Responsive Behavior

**Breakpoints:**
- Mobile: < 768px - Single column, stacked layout, bottom navigation
- Tablet: 768px-1024px - Two columns where appropriate, collapsible sidebar
- Desktop: > 1024px - Full sidebar, multi-column grids

**Mobile Optimizations:**
- Floating Add Expense button (bottom-right corner, fixed)
- Swipeable expense cards for actions
- Simplified header with hamburger menu
- Bottom tab navigation instead of sidebar

---

## Interactive States

**Buttons:**
- Default: Solid with defined padding
- Hover: Slight scale (scale-105) or brightness adjustment
- Active: scale-95
- Disabled: opacity-50 cursor-not-allowed

**Form Inputs:**
- Default: Neutral border
- Focus: Ring effect, border color change
- Filled: Maintain focus indication
- Error: Red border, shake animation on validation fail

**List Items:**
- Hover: Background tint, shadow increase
- Selected: Border accent, background tint
- Click: Ripple effect (Material Design)

---

## Images & Visual Assets

**Authentication Pages:**
- Hero Image: Financial illustration or abstract data visualization on left side of split-screen
  - Style: Modern, clean illustrations showing expense tracking concepts
  - Placement: 40% left section on desktop, hidden on mobile
  - Treatment: Subtle overlay to ensure text readability if text overlays

**Dashboard:**
- Empty states: Illustrations when no expenses exist
  - Message: "No expenses yet! Start tracking by adding your first expense"
  - Illustration: Friendly, encouraging graphic
- Category icons: Consistent icon set for all expense categories

**No large hero image on dashboard** - prioritize data visibility and quick access to features

---

## Accessibility & UX Details

- Minimum touch target: 44x44px for all interactive elements
- Form labels always visible (no placeholder-only inputs)
- Clear focus indicators for keyboard navigation
- Loading states for async operations (skeleton screens for data loading)
- Success confirmations after creating/editing expenses (toast notifications)
- Undo option for deletions (5-second timeout with toast)
- Empty states with clear CTAs
- Error messages with actionable recovery steps

---

## Animation Guidelines

Use sparingly and purposefully:
- Page transitions: Fade-in (200ms)
- Modal entrance: Scale from 95% + fade (150ms)
- List item additions: Slide down + fade (200ms)
- Hover effects: Transition duration-200
- Loading spinners: For operations > 300ms
- Success checkmarks: Scale bounce animation
- **Avoid:** Excessive micro-interactions, distracting background animations